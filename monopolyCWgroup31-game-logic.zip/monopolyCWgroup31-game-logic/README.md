# monopolyCWgroup31

Monopoly game coursework, this project is property of group 31 from University of Sussex, Computer Science course.

Authors:
Hasib 
Christian
Omar
Charlie
Alex
