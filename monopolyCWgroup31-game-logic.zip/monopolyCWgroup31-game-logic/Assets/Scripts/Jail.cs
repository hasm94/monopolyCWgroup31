﻿internal class Jail : Tile
{
    public Jail(string n) : base(n)
    {
    }

    public void CompleteAction(Player p)
    {

    }
}