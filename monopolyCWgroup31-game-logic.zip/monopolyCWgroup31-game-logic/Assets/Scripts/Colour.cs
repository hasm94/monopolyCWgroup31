public enum Colour
{
    //Different colours that the streets can have, is a public class so that the individual properties can have a colour too.
    BROWN, DEEP_BLUE, PURPLE, ORANGE, RED, YELLOW, GREEN, BLUE, UTILITY, TRANSPORT
}
