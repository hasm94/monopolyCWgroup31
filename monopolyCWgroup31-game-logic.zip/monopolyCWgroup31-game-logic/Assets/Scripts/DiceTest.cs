﻿using UnityEngine;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;

public class DiceTest {

	[Test]
	public void DiceTestSimplePasses() {
		// Use the Assert class to test conditions.
	}


	[UnityTest]
	public IEnumerator DiceTestWithEnumeratorPasses() {

		Monopoly monopoly = GameObject.FindObjectOfType<Monopoly>();
		DiceRoller diceRoller = GameObject.FindObjectOfType<DiceRoller>();
		int diceTotal;
		Player player = GameObject.FindObjectOfType<Player>();

		yield return null;

		diceRoller.RollTheDice ();
		diceTotal = diceRoller.dice [0] + diceRoller.dice [1];

		monopoly.isDoneRolling = true;

		player.MakeMove ();

		Assert.AreEqual (player.spacesToMoveForTest, diceTotal);

	}
}
