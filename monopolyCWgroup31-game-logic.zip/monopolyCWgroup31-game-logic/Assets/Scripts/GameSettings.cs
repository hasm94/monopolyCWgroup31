﻿using UnityEngine;

public class GameSettings : MonoBehaviour
{

    public int noPlayers;

    // Use this for initialization
    void Start()
    {

        //noPlayers = 

    }

    // Update is called once per frame
    void Update()
    {

    }
}
